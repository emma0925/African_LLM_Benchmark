dir = '/emmazhuang/Documents/Codes/Masakhane/results_nli/gemmaUltra200k/'
print(dir.split('/')[-2])